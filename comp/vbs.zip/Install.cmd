@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo Установка базовых пакетов
echo ------------------------------------

for %%f in (*.cab) do (echo %%f | findstr /v /i "ru-ru" >nul && (echo %%f & wl -add -package "%%f" -hide))

echo.
echo Установка языковых пакетов
echo ------------------------------------

for %%f in (*ru-ru*.cab) do (echo %%f & wl -add -package "%%f" -hide)

echo.
echo Все задачи выполнены!
pause